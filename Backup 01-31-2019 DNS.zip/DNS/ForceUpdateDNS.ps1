$ipvivo = (Resolve-DnsName -Server 8.8.8.8 home-vivo.no-ip.info).IpAddress
$iptim = (Resolve-DnsName -Server 8.8.8.8 home-tim.no-ip.info).IpAddress
$ipns1= (Resolve-DnsName -Server 8.8.8.8 havranekns1.cloudapp.net).IpAddress
$ipns2= (Resolve-DnsName -Server 8.8.8.8 havranekns2.cloudapp.net).IpAddress
$iprp= (Resolve-DnsName -Server 8.8.8.8 havranekrp01.cloudapp.net).IpAddress
Write-Host "IP VIVO: $ipvivo " 
Write-Host "IP TIM: $iptim " 
Write-Host "Current IP: $ipconfigured - " 

Write-Host "IP have Changed... Starting to Update."

# sipfed.havra.me --> vivo
$cmdDelete = "dnscmd havranek-DC01 /RecordDelete havra.me sipfed A /f"
$cmdAdd = "dnscmd havranek-DC01 /RecordAdd havra.me sipfed A $ipvivo"
Write-Host "Running the following command: $cmdDelete" 
Invoke-Expression $cmdDelete 
Write-Host "Running the following command: $cmdAdd" 
Invoke-Expression $cmdAdd 

# vpn.havra.me --> tim
$cmdDelete = "dnscmd havranek-DC01 /RecordDelete havra.me vpn A /f"
$cmdAdd = "dnscmd havranek-DC01 /RecordAdd havra.me vpn A $iptim"
Write-Host "Running the following command: $cmdDelete" 
Invoke-Expression $cmdDelete 
Write-Host "Running the following command: $cmdAdd" 
Invoke-Expression $cmdAdd 
